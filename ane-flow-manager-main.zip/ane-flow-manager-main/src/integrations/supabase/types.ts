export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      alunos_ativos: {
        Row: {
          cpf: string | null
          created_at: string
          curso: string | null
          data_matricula: string | null
          data_nascimento: string | null
          email: string | null
          id: string
          nome_completo: string
          observacoes: string | null
          pendencias: number | null
          status: string
          telefone: string
          updated_at: string
          valor_pago: number | null
          valor_total: number | null
          vencimento: string | null
        }
        Insert: {
          cpf?: string | null
          created_at?: string
          curso?: string | null
          data_matricula?: string | null
          data_nascimento?: string | null
          email?: string | null
          id?: string
          nome_completo: string
          observacoes?: string | null
          pendencias?: number | null
          status?: string
          telefone: string
          updated_at?: string
          valor_pago?: number | null
          valor_total?: number | null
          vencimento?: string | null
        }
        Update: {
          cpf?: string | null
          created_at?: string
          curso?: string | null
          data_matricula?: string | null
          data_nascimento?: string | null
          email?: string | null
          id?: string
          nome_completo?: string
          observacoes?: string | null
          pendencias?: number | null
          status?: string
          telefone?: string
          updated_at?: string
          valor_pago?: number | null
          valor_total?: number | null
          vencimento?: string | null
        }
        Relationships: []
      }
      clientes: {
        Row: {
          cpf: string | null
          created_at: string
          data_nascimento: string | null
          email: string | null
          id: string
          nome_completo: string
          telefone: string
          updated_at: string
        }
        Insert: {
          cpf?: string | null
          created_at?: string
          data_nascimento?: string | null
          email?: string | null
          id: string
          nome_completo: string
          telefone: string
          updated_at?: string
        }
        Update: {
          cpf?: string | null
          created_at?: string
          data_nascimento?: string | null
          email?: string | null
          id?: string
          nome_completo?: string
          telefone?: string
          updated_at?: string
        }
        Relationships: []
      }
      pendencias: {
        Row: {
          created_at: string
          data_criacao: string
          descricao: string | null
          id: string
          responsavel: string | null
          session_id: string | null
          status: string
          tipo: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          data_criacao?: string
          descricao?: string | null
          id: string
          responsavel?: string | null
          session_id?: string | null
          status?: string
          tipo?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          data_criacao?: string
          descricao?: string | null
          id?: string
          responsavel?: string | null
          session_id?: string | null
          status?: string
          tipo?: string
          updated_at?: string
        }
        Relationships: []
      }
      plano_permissoes: {
        Row: {
          created_at: string
          id: string
          permissao: Database["public"]["Enums"]["permissao_tipo"]
          plano_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          permissao: Database["public"]["Enums"]["permissao_tipo"]
          plano_id: string
        }
        Update: {
          created_at?: string
          id?: string
          permissao?: Database["public"]["Enums"]["permissao_tipo"]
          plano_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "plano_permissoes_plano_id_fkey"
            columns: ["plano_id"]
            isOneToOne: false
            referencedRelation: "planos"
            referencedColumns: ["id"]
          },
        ]
      }
      planos: {
        Row: {
          ativo: boolean
          created_at: string
          descricao: string | null
          id: string
          limite_atendimentos_mes: number | null
          limite_usuarios: number | null
          nome: string
          preco_mensal: number | null
          tipo: Database["public"]["Enums"]["plano_tipo"]
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          limite_atendimentos_mes?: number | null
          limite_usuarios?: number | null
          nome: string
          preco_mensal?: number | null
          tipo: Database["public"]["Enums"]["plano_tipo"]
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          limite_atendimentos_mes?: number | null
          limite_usuarios?: number | null
          nome?: string
          preco_mensal?: number | null
          tipo?: Database["public"]["Enums"]["plano_tipo"]
          updated_at?: string
        }
        Relationships: []
      }
      registros_atendimento: {
        Row: {
          assunto: string
          cliente_id: string | null
          concluido_gestor: boolean | null
          created_at: string
          data_conclusao_gestor: string | null
          data_hora: string
          detalhes: string | null
          id: string
          nome_cliente: string | null
          session_id: string
          status_geral: string
          status_gestao: string | null
          telefone_cliente: string
          updated_at: string
        }
        Insert: {
          assunto: string
          cliente_id?: string | null
          concluido_gestor?: boolean | null
          created_at?: string
          data_conclusao_gestor?: string | null
          data_hora?: string
          detalhes?: string | null
          id: string
          nome_cliente?: string | null
          session_id: string
          status_geral?: string
          status_gestao?: string | null
          telefone_cliente: string
          updated_at?: string
        }
        Update: {
          assunto?: string
          cliente_id?: string | null
          concluido_gestor?: boolean | null
          created_at?: string
          data_conclusao_gestor?: string | null
          data_hora?: string
          detalhes?: string | null
          id?: string
          nome_cliente?: string | null
          session_id?: string
          status_geral?: string
          status_gestao?: string | null
          telefone_cliente?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "registros_atendimento_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
        ]
      }
      user_planos: {
        Row: {
          atendimentos_usados_mes: number | null
          ativo: boolean
          created_at: string
          data_fim: string | null
          data_inicio: string
          id: string
          plano_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          atendimentos_usados_mes?: number | null
          ativo?: boolean
          created_at?: string
          data_fim?: string | null
          data_inicio?: string
          id?: string
          plano_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          atendimentos_usados_mes?: number | null
          ativo?: boolean
          created_at?: string
          data_fim?: string | null
          data_inicio?: string
          id?: string
          plano_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_planos_plano_id_fkey"
            columns: ["plano_id"]
            isOneToOne: false
            referencedRelation: "planos"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_settings: {
        Row: {
          created_at: string
          id: string
          simulation_enabled: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          simulation_enabled?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          simulation_enabled?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_rate_limit: {
        Args: { operation_type: string }
        Returns: boolean
      }
      get_user_plano: {
        Args: { _user_id: string }
        Returns: {
          permissoes: Database["public"]["Enums"]["permissao_tipo"][]
          plano_nome: string
          plano_tipo: Database["public"]["Enums"]["plano_tipo"]
        }[]
      }
      has_permission: {
        Args: {
          _permissao: Database["public"]["Enums"]["permissao_tipo"]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      is_authenticated: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      marcar_atendimento_concluido: {
        Args: { session_id_param: string }
        Returns: undefined
      }
      promote_user_to_admin: {
        Args: { user_email: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "user"
      permissao_tipo:
        | "visualizar_dados"
        | "criar_registros"
        | "editar_registros"
        | "deletar_registros"
        | "acessar_relatorios"
        | "gerenciar_usuarios"
        | "admin_total"
      plano_tipo: "basico" | "premium" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
      permissao_tipo: [
        "visualizar_dados",
        "criar_registros",
        "editar_registros",
        "deletar_registros",
        "acessar_relatorios",
        "gerenciar_usuarios",
        "admin_total",
      ],
      plano_tipo: ["basico", "premium", "admin"],
    },
  },
} as const

import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Converte uma data no formato brasileiro (DD/MM/AAAA) para o formato ISO (AAAA-MM-DD)
 * @param dataBr Data no formato DD/MM/AAAA
 * @returns Data no formato AAAA-MM-DD ou null se inválida
 */
export function formatarDataParaISO(input: string): string | null {
  // SIMPLIFICADO: Aceita qualquer formato e apenas retorna como está
  // Se vazio, retorna null; caso contrário, retorna o input sem modificação
  return input ? input.trim() : null;
}

/**
 * Converte uma data no formato ISO (AAAA-MM-DD) para o formato brasileiro (DD/MM/AAAA)
 * @param dataISO Data no formato AAAA-MM-DD
 * @returns Data no formato DD/MM/AAAA ou string vazia se inválida
 */
export function formatarDataParaBR(dataInput: string): string {
  if (!dataInput) return '';
  
  try {
    // Se já está no formato brasileiro (DD/MM/YYYY), retorna como está
    const regexBR = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
    const matchBR = dataInput.match(regexBR);
    
    if (matchBR) {
      const [, dia, mes, ano] = matchBR;
      // Formatar com zeros à esquerda se necessário
      return `${dia.padStart(2, '0')}/${mes.padStart(2, '0')}/${ano}`;
    }
    
    // Se está no formato ISO (YYYY-MM-DD), converte para brasileiro
    const regexISO = /^(\d{4})-(\d{2})-(\d{2})$/;
    const matchISO = dataInput.match(regexISO);
    
    if (matchISO) {
      const [, ano, mes, dia] = matchISO;
      return `${dia}/${mes}/${ano}`;
    }
    
    return '';
  } catch {
    return '';
  }
}

/**
 * Valida se uma opção de menu é válida (número entre 1 e máximo)
 * @param opcao Opção selecionada pelo usuário
 * @param maximo Número máximo de opções disponíveis
 * @returns Número da opção se válida, null se inválida
 */
export function validarOpcaoMenu(opcao: string, maximo: number): number | null {
  if (opcao == null) return null;

  // Aceita números, textos e emojis (ex: 1️⃣, "opção 2", "dois")
  const raw = String(opcao).trim();
  if (!raw) return null;

  // Normaliza acentos e caixa
  const normalized = raw
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();

  // 1) Tenta extrair o primeiro número presente (suporta 1, 2., 3- , 1️⃣, etc.)
  const digitMatch = normalized.match(/\d+/);
  if (digitMatch) {
    const numero = parseInt(digitMatch[0], 10);
    if (!isNaN(numero) && numero >= 1 && numero <= maximo) {
      return numero;
    }
  }

  // 2) Tenta mapear palavras comuns em PT-BR para números (1-9)
  const wordMap: Record<string, number> = {
    um: 1, uma: 1, primeiro: 1, primeira: 1,
    dois: 2, segundo: 2, segunda: 2,
    tres: 3, terceiro: 3, terceira: 3,
    quatro: 4, quarto: 4, quarta: 4,
    cinco: 5, quinto: 5, quinta: 5,
    seis: 6, sexto: 6, sexta: 6,
    sete: 7, setimo: 7, setima: 7,
    oito: 8, oitavo: 8, oitava: 8,
    nove: 9, nono: 9, nona: 9,
  };

  for (const [palavra, valor] of Object.entries(wordMap)) {
    const regex = new RegExp(`\\b${palavra}\\b`, 'i');
    if (regex.test(normalized) && valor >= 1 && valor <= maximo) {
      return valor;
    }
  }

  return null;
}

/**
 * Formata uma data no fuso horário de São Paulo (Brasil)
 * - Apenas data: dd/mm/aaaa
 */
export function formatarDataBRTimeZone(dateInput: string | Date): string {
  try {
    const date = new Date(dateInput);
    return new Intl.DateTimeFormat('pt-BR', {
      timeZone: 'America/Sao_Paulo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(date);
  } catch {
    return '';
  }
}

/**
 * Formata data e hora no fuso horário de São Paulo (Brasil)
 * - Data e hora curtas: dd/mm/aaaa HH:mm
 */
export function formatarDataHoraBRTimeZone(dateInput: string | Date): string {
  try {
    const date = new Date(dateInput);
    return new Intl.DateTimeFormat('pt-BR', {
      timeZone: 'America/Sao_Paulo',
      dateStyle: 'short',
      timeStyle: 'short',
    }).format(date);
  } catch {
    return '';
  }
}

/**
 * Mapeia opções do menu de cursos para suas descrições
 */
export const MENU_CURSOS = {
  1: 'Ensino Fundamental (EJA)',
  2: 'Ensino Fundamental + Médio (EJA)', 
  3: 'Ensino Médio',
  4: 'Graduação',
  5: 'Pós-graduação',
  6: 'Mestrado, Doutorado e Pós-Doutorado',
  7: 'Técnico por Competência',
  8: 'Cursos Técnicos e Pós-Técnicos',
  9: 'Cursos Profissionalizantes'
} as const;

/**
 * Obtém a descrição de um curso pela opção selecionada
 * @param opcao Número da opção (1-9)
 * @returns Descrição do curso ou null se opção inválida
 */
export function obterDescricaoCurso(opcao: number): string | null {
  return MENU_CURSOS[opcao as keyof typeof MENU_CURSOS] || null;
}

/**
 * Calcula a idade baseada na data de nascimento
 * @param dataNascimento Data de nascimento em formato ISO (YYYY-MM-DD) ou BR (DD/MM/YYYY)
 * @returns Idade em anos ou null se data inválida
 */
export function calcularIdade(dataNascimento: string): number | null {
  if (!dataNascimento) return null;
  
  try {
    let dataFormatada: Date;
    
    // Tenta diferentes formatos de data
    if (dataNascimento.includes('/')) {
      // Formato DD/MM/YYYY
      const [dia, mes, ano] = dataNascimento.split('/');
      dataFormatada = new Date(parseInt(ano), parseInt(mes) - 1, parseInt(dia));
    } else if (dataNascimento.includes('-')) {
      // Formato YYYY-MM-DD
      dataFormatada = new Date(dataNascimento);
    } else {
      return null;
    }
    
    if (isNaN(dataFormatada.getTime())) return null;
    
    const hoje = new Date();
    let idade = hoje.getFullYear() - dataFormatada.getFullYear();
    const mesAtual = hoje.getMonth();
    const diaAtual = hoje.getDate();
    const mesNascimento = dataFormatada.getMonth();
    const diaNascimento = dataFormatada.getDate();
    
    // Ajusta a idade se ainda não fez aniversário este ano
    if (mesAtual < mesNascimento || (mesAtual === mesNascimento && diaAtual < diaNascimento)) {
      idade--;
    }
    
    return idade >= 0 ? idade : null;
  } catch {
    return null;
  }
}
